Custom newtab for Firefox.

![Screenshot](images/screenshot.png)

### Features
- Local notes
- Dynamic background image
- Smart search bar
    - `y query` for Youtube, `d query` for Google Drive, etc.